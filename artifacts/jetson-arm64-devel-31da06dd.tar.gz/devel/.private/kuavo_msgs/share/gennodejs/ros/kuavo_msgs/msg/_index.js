
"use strict";

let ikSolveParam = require('./ikSolveParam.js');
let headBodyPose = require('./headBodyPose.js');
let dexhandTouchState = require('./dexhandTouchState.js');
let robotHeadMotionData = require('./robotHeadMotionData.js');
let endEffectorData = require('./endEffectorData.js');
let handPose = require('./handPose.js');
let mpc_input = require('./mpc_input.js');
let gestureTask = require('./gestureTask.js');
let Metadata = require('./Metadata.js');
let jointData = require('./jointData.js');
let mpc_target_trajectories = require('./mpc_target_trajectories.js');
let armHandPose = require('./armHandPose.js');
let twoArmHandPoseCmd = require('./twoArmHandPoseCmd.js');
let yoloDetection = require('./yoloDetection.js');
let AudioReceiverData = require('./AudioReceiverData.js');
let gestureInfo = require('./gestureInfo.js');
let gaitTimeName = require('./gaitTimeName.js');
let recordArmHandPose = require('./recordArmHandPose.js');
let robotState = require('./robotState.js');
let armTargetPoses = require('./armTargetPoses.js');
let bezierCurveCubicPoint = require('./bezierCurveCubicPoint.js');
let footPoses = require('./footPoses.js');
let AprilTagDetectionArray = require('./AprilTagDetectionArray.js');
let questJoySticks = require('./questJoySticks.js');
let sensorsData = require('./sensorsData.js');
let robotHandPosition copy = require('./robotHandPosition copy.js');
let footPose = require('./footPose.js');
let robotArmQVVD = require('./robotArmQVVD.js');
let dexhandCommand = require('./dexhandCommand.js');
let mpc_state = require('./mpc_state.js');
let imuData = require('./imuData.js');
let TFArray = require('./TFArray.js');
let jointCmd = require('./jointCmd.js');
let lejuClawCommand = require('./lejuClawCommand.js');
let yoloOutputData = require('./yoloOutputData.js');
let AprilTagDetection = require('./AprilTagDetection.js');
let FTsensorData = require('./FTsensorData.js');
let switchGaitByName = require('./switchGaitByName.js');
let touchSensorStatus = require('./touchSensorStatus.js');
let twoArmHandPose = require('./twoArmHandPose.js');
let lejuClawState = require('./lejuClawState.js');
let ikSolveError = require('./ikSolveError.js');
let jointBezierTrajectory = require('./jointBezierTrajectory.js');
let robotHandPosition = require('./robotHandPosition.js');
let footPoseTargetTrajectories = require('./footPoseTargetTrajectories.js');
let armPoseWithTimeStamp = require('./armPoseWithTimeStamp.js');

module.exports = {
  ikSolveParam: ikSolveParam,
  headBodyPose: headBodyPose,
  dexhandTouchState: dexhandTouchState,
  robotHeadMotionData: robotHeadMotionData,
  endEffectorData: endEffectorData,
  handPose: handPose,
  mpc_input: mpc_input,
  gestureTask: gestureTask,
  Metadata: Metadata,
  jointData: jointData,
  mpc_target_trajectories: mpc_target_trajectories,
  armHandPose: armHandPose,
  twoArmHandPoseCmd: twoArmHandPoseCmd,
  yoloDetection: yoloDetection,
  AudioReceiverData: AudioReceiverData,
  gestureInfo: gestureInfo,
  gaitTimeName: gaitTimeName,
  recordArmHandPose: recordArmHandPose,
  robotState: robotState,
  armTargetPoses: armTargetPoses,
  bezierCurveCubicPoint: bezierCurveCubicPoint,
  footPoses: footPoses,
  AprilTagDetectionArray: AprilTagDetectionArray,
  questJoySticks: questJoySticks,
  sensorsData: sensorsData,
  robotHandPosition copy: robotHandPosition copy,
  footPose: footPose,
  robotArmQVVD: robotArmQVVD,
  dexhandCommand: dexhandCommand,
  mpc_state: mpc_state,
  imuData: imuData,
  TFArray: TFArray,
  jointCmd: jointCmd,
  lejuClawCommand: lejuClawCommand,
  yoloOutputData: yoloOutputData,
  AprilTagDetection: AprilTagDetection,
  FTsensorData: FTsensorData,
  switchGaitByName: switchGaitByName,
  touchSensorStatus: touchSensorStatus,
  twoArmHandPose: twoArmHandPose,
  lejuClawState: lejuClawState,
  ikSolveError: ikSolveError,
  jointBezierTrajectory: jointBezierTrajectory,
  robotHandPosition: robotHandPosition,
  footPoseTargetTrajectories: footPoseTargetTrajectories,
  armPoseWithTimeStamp: armPoseWithTimeStamp,
};
