// Auto-generated. Do not edit!

// (in-package kuavo_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class FTsensorData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.Fx = null;
      this.Fy = null;
      this.Fz = null;
      this.Mx = null;
      this.My = null;
      this.Mz = null;
    }
    else {
      if (initObj.hasOwnProperty('Fx')) {
        this.Fx = initObj.Fx
      }
      else {
        this.Fx = [];
      }
      if (initObj.hasOwnProperty('Fy')) {
        this.Fy = initObj.Fy
      }
      else {
        this.Fy = [];
      }
      if (initObj.hasOwnProperty('Fz')) {
        this.Fz = initObj.Fz
      }
      else {
        this.Fz = [];
      }
      if (initObj.hasOwnProperty('Mx')) {
        this.Mx = initObj.Mx
      }
      else {
        this.Mx = [];
      }
      if (initObj.hasOwnProperty('My')) {
        this.My = initObj.My
      }
      else {
        this.My = [];
      }
      if (initObj.hasOwnProperty('Mz')) {
        this.Mz = initObj.Mz
      }
      else {
        this.Mz = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FTsensorData
    // Serialize message field [Fx]
    bufferOffset = _arraySerializer.float64(obj.Fx, buffer, bufferOffset, null);
    // Serialize message field [Fy]
    bufferOffset = _arraySerializer.float64(obj.Fy, buffer, bufferOffset, null);
    // Serialize message field [Fz]
    bufferOffset = _arraySerializer.float64(obj.Fz, buffer, bufferOffset, null);
    // Serialize message field [Mx]
    bufferOffset = _arraySerializer.float64(obj.Mx, buffer, bufferOffset, null);
    // Serialize message field [My]
    bufferOffset = _arraySerializer.float64(obj.My, buffer, bufferOffset, null);
    // Serialize message field [Mz]
    bufferOffset = _arraySerializer.float64(obj.Mz, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FTsensorData
    let len;
    let data = new FTsensorData(null);
    // Deserialize message field [Fx]
    data.Fx = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [Fy]
    data.Fy = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [Fz]
    data.Fz = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [Mx]
    data.Mx = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [My]
    data.My = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [Mz]
    data.Mz = _arrayDeserializer.float64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 8 * object.Fx.length;
    length += 8 * object.Fy.length;
    length += 8 * object.Fz.length;
    length += 8 * object.Mx.length;
    length += 8 * object.My.length;
    length += 8 * object.Mz.length;
    return length + 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'kuavo_msgs/FTsensorData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8c354019984e4c7a3d3809359701bdc4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64[] Fx  
    float64[] Fy  
    float64[] Fz    
    float64[] Mx  
    float64[] My  
    float64[] Mz  
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FTsensorData(null);
    if (msg.Fx !== undefined) {
      resolved.Fx = msg.Fx;
    }
    else {
      resolved.Fx = []
    }

    if (msg.Fy !== undefined) {
      resolved.Fy = msg.Fy;
    }
    else {
      resolved.Fy = []
    }

    if (msg.Fz !== undefined) {
      resolved.Fz = msg.Fz;
    }
    else {
      resolved.Fz = []
    }

    if (msg.Mx !== undefined) {
      resolved.Mx = msg.Mx;
    }
    else {
      resolved.Mx = []
    }

    if (msg.My !== undefined) {
      resolved.My = msg.My;
    }
    else {
      resolved.My = []
    }

    if (msg.Mz !== undefined) {
      resolved.Mz = msg.Mz;
    }
    else {
      resolved.Mz = []
    }

    return resolved;
    }
};

module.exports = FTsensorData;
