# generated from genmsg/cmake/pkg-msg-paths.cmake.develspace.in

set(kuavo_msgs_MSG_INCLUDE_DIRS "/home/leju_kuavo/kuavo_ros_application/src/kuavo_msgs/msg")
set(kuavo_msgs_MSG_DEPENDENCIES std_msgs;geometry_msgs)
