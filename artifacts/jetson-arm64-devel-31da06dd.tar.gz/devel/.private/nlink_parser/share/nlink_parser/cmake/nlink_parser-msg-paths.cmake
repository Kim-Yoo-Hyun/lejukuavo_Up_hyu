# generated from genmsg/cmake/pkg-msg-paths.cmake.develspace.in

set(nlink_parser_MSG_INCLUDE_DIRS "/home/leju_kuavo/kuavo_ros_application/src/ros_localization/nlink_parser/msg")
set(nlink_parser_MSG_DEPENDENCIES std_msgs)
