
"use strict";

let SetString = require('./SetString.js')
let SetBool = require('./SetBool.js')
let GetCameraParams = require('./GetCameraParams.js')
let GetInt32 = require('./GetInt32.js')
let GetCameraInfo = require('./GetCameraInfo.js')
let GetBool = require('./GetBool.js')
let SetInt32 = require('./SetInt32.js')
let GetDeviceInfo = require('./GetDeviceInfo.js')
let GetString = require('./GetString.js')

module.exports = {
  SetString: SetString,
  SetBool: SetBool,
  GetCameraParams: GetCameraParams,
  GetInt32: GetInt32,
  GetCameraInfo: GetCameraInfo,
  GetBool: GetBool,
  SetInt32: SetInt32,
  GetDeviceInfo: GetDeviceInfo,
  GetString: GetString,
};
